<html>
<head>
    <title>Fira FP | Administració</title>
    <script src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/main.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/angular.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/checkbox.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/CentreEstudisAng.js') ?>"></script>

    <script src="<?php echo base_url('assets/js/simplemde.min.js') ?>"></script>

    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/main.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/login.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/simplemde.min.css'); ?>">

    <script src="https://use.fontawesome.com/bb601fc6ec.js"></script>
    <meta charset="utf-8" />
</head>
<body ng-app="firaft">
