<script>
    app.controller('AdminisController', function($scope) {
        $scope.dades = <?php echo $dades; ?>;

        $scope.setCurrentDelete = function(currentDel){
            $scope.currentDelete = currentDel;
        }
    });
</script>
<div class="container" ng-controller="AdminisController">

    <div class="input-group" style="margin-bottom: 15px !important;">
        <span class="input-group-addon" id="basic-addon1">
            <i class="fa fa-search"></i>
        </span>
        <input type="search" class="form-control square-input" ng-init="buscarDada=''" placeholder="Buscar registre per qualsevol de les seves dades..." ng-model="buscarDada"/>
        <span class="input-group-btn">
            <button class="btn btn-success square-btn" data-toggle="modal" data-target="#myModal"><i class="fa fa-plus"></i> Afegir registre</button>
        </span>
    </div>

    <table class="table table-hover" style="">

        <tr>
            <?php
                foreach ($columnes as $key => $columna) {
                    if($key != '0'){
            ?>
                <th><?php echo $columna; ?></th>
            <?php }} ?>
            <th style="text-align:center" colspan="2">Opcions</th>
        </tr>

        <tr ng-repeat="dada in dades | filter: buscarDada">
            <td ng-repeat="simpledata in dada" ng-hide="$index=='0'">
                <span>{{simpledata}}</span>
            </td>

            <td style="text-align:center;">
                <div class="btn-group" role="group" aria-label="...">
                    <a href="<?php echo base_url('editar/'.$database.'/{{dada.id}}'); ?>" class="btn btn-warning">
                        <i class="fa fa-pencil"></i> Editar
                    </a>
                    <?php if($database=='centers') { ?>
                        <a href="<?php echo base_url('centres_estudis/{{dada.id}}'); ?>" class="btn btn-primary">
                            <i class="fa fa-book"></i> Administrar estudis
                        </a>
                    <?php } ?>

                    <a ng-click="setCurrentDelete(dada)" data-toggle="modal" data-target="#deleteModal" href="<?php //echo base_url('admin/delete/'.$database.'/{{dada.id}}'); ?>" class="btn btn-danger">
                        <i class="fa fa-trash-o"></i> Eliminar
                    </a>
                </div>
            </td>
        </tr>
    </table>

    <!-- Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Confirmación</h4>
                </div>
                <div class="modal-body">
                    <span>¿Desea eliminar el registro "<strong>{{currentDelete.name}}{{currentDelete.title}}</strong>"?</span>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                        <i class="fa fa-times"></i> Cancel·lar
                    </button>
                    <a href="<?php echo base_url('admin/delete/'.$database.'/{{currentDelete.id}}'); ?>" class="btn btn-danger">
                        <i class="fa fa-trash-o"></i> Eliminar
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
